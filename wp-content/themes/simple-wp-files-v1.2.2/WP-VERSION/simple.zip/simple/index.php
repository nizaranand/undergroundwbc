<?php get_header() ?>
<div class="content-blog">
<!-- CONTENT BELOW -->
		<!-- POSTS -->
		<div id="posts">
			<?php if( have_posts() ) : while ( have_posts() ) : the_post(); ?>
			<!-- post -->
			<div class="post">
				<!-- post-header -->
				<div class="post-header">
					<div class="post-title"><a href="<?php the_permalink() ?>" ><?php the_title() ?></a></div>
					<div class="post-meta <?php if(get_option('simple_meta_display') == 'checked') echo 'inv' ?>">
						POSTED BY <?php echo get_the_author_link() ?> IN <?php the_category(', ') ?>
					</div>
					<div class="n-comments"><?php comments_number('0', '1', '%') ?></div>
				</div>
				<!-- ENDS post-header -->
				<!-- post-img -->
				<div class="post-img">
					<div class="date <?php if(get_option('simple_metadate_display') == 'checked' or get_option('simple_featureimage_display') == 'checked') echo 'inv' ?>">
						<div class="day custom"><?php the_time('d') ?></div>
						<div class="month custom"><?php the_time('M') ?><br/><?php the_time('Y') ?></div>
					</div>
					<div class="clip-feature <?php if(get_option('simple_featureimage_display') == 'checked') echo 'inv' ?> ">
					<?php if(has_post_thumbnail()) : ?>
						<?php	the_post_thumbnail() ?>
					<?php else: ?>
						<img src="<?php bloginfo('template_url') ?>/img/na-feature.gif" alt="Image not available"  />
					<?php endif; ?>
					</div>
		 		</div>
		 		<!-- ENDS post-img -->
			 		<div class="excerpt"><?php the_excerpt() ?></div>
			 		<br/>
					<p><a href="<?php the_permalink() ?>" class="link-button right"><span>MORE</span></a></p>
			</div>
			<!-- ENDS post -->
			
			<?php endwhile; else:  ?>
			<!-- oops -->
			<div class="woops">	
				<h2>Woops...</h2>  
				<p>Sorry, no posts we're found.</p> 
			</div>	
			<?php endif; ?>
			<!-- ENDS oops -->
			
			<!-- blog-pager -->
			<ul class="portfolio-pager">
				<li class="first-child"><?php previous_posts_link('NEWER') ?></li>
				<li class="last-child"><?php  next_posts_link('OLDER') ?></li>
			</ul>
			<!-- ENDS blog-pager -->
			
		</div>	
		<!-- ENDS POSTS -->

		<!-- sidebar -->
		<?php get_sidebar() ?>
		<!-- ENDS sidebar -->


<!-- CONTENT ABOVE -->
</div>
<?php get_footer() ?>