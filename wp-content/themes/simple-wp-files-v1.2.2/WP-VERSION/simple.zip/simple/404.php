<?php get_header() ?>
<div class="content">
<!-- CONTENT BELOW -->


<!-- title -->
	<div class="title-holder">
		<span class="title">ERROR 404</span>
		<span class="subtitle"></span>
	</div>
	<!-- ENDS title -->
	
	<!-- page-content -->
	<div class="page-content">
	<?php echo get_option('simple_404') ?>
	</div>



<!-- CONTENT ABOVE -->
</div>
<?php get_footer() ?>
