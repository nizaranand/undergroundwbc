<?php get_header() ?>
<div class="content">
<!-- CONTENT BELOW -->
			
	<!-- title -->
	<div class="title-holder">
		<span class="title"><?php echo get_option('simple_portfolio_title') ?></span>
		<span class="subtitle"><?php echo nl2br(get_option('simple_portfolio_subtitle')) ?></span>
	</div>
	<!-- ENDS title -->
	
	<!-- page-content -->
	<div class="page-content">
	
	
		<!-- holder -->
		<div class="holder">
			<!-- portfolio-sidebar -->
			<div class="portfolio-sidebar">
				<?php if(get_option('simple_portfolio_categories_display') == "" ) : ?>
				<h2><?php echo get_option('simple_portfolio_categories_label') ?></h2>
				<ul>
					<?php 
					$args = array(
					    		'taxonomy' => 'category_portfolio'
					    		);
					$categories = get_categories( $args );
					foreach($categories as $cat){
						$link_url = $cat->category_nicename;
						$name = $cat->cat_name;
						echo '<li><a href="'.get_bloginfo('url').'/portfolios?cat='.$link_url.'">'.$name.'</a></li>';
					} ?>
				</ul>
			</div>
			<?php endif; ?>
			<!-- ENDS portfolio-sidebar -->
			<!-- portfolio-content -->
			<div class="holder">
				<ul class="portfolio-thumbs">
				
					<?php
					// query for portfolio
					global $query_string;
					$np = get_option('simple_portfolio_nposts');
					query_posts($query_string . "&post_type=portfolio&category_portfolio=".$_GET['cat']."&posts_per_page=".$np);
				
					if( have_posts() ) : while ( have_posts() ) : the_post(); 
					
					// portfolio data
					$custom = get_post_custom($post->ID);
					$client =  $custom["client"][0];
					$date =  $custom["date"][0];
					$link =  $custom["link"][0];
					$link =  "<a href='".$link."'>" . $link . "</a>";
					?>	
				<li>
				
					<!-- image -->
					<div class="clip-portfolio">
					<?php if(has_post_thumbnail()) : ?>
						<?php	the_post_thumbnail() ?>
					<?php else: ?>
						<a href="<?php the_permalink() ?>">
						<img src="<?php bloginfo('template_url') ?>/img/na-image.gif" alt="Image not available"  />
						</a>
					<?php endif; ?>
					</div>
					<!-- ENDS image -->
				
					<div class="name"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></div>
					<div class="sub-name"><?php echo get_option('simple_portfolio_client_label')." ".$client ?></div>
				</li>
				
				<?php endwhile; else:  ?>
				<!-- oops -->
				<div class="woops">	
					<h2>Woops...</h2>  
					<p>Sorry, no portfolio projects we're found.</p> 
				</div>	
				<?php endif; ?>
				<!-- ENDS oops -->
	
				</ul>
				<!-- portfolio-pager -->
				<div class="pager">
					<p class="clear"></p>
					<ul class="portfolio-pager">
						<li class="first-child"><?php previous_posts_link('NEWER') ?></li>
						<li class="last-child"><?php  next_posts_link('OLDER') ?></li>
					</ul>
				</div>
				<!-- ENDS portfolio-pager -->
			</div>
			<!-- ENDS portfolio-content -->
		</div>
		<!-- ENDS holder -->	
						
						
<!-- CONTENT ABOVE -->
</div>
<?php get_footer() ?>