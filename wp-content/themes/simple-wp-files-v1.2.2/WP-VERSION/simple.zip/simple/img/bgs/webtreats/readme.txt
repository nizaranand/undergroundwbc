Thanks For Downloading!
This resource is free for personal and commercial use ~ no attribution necessary.
Find many more quality resources on the Mysitemyway ETC Network.

Icons ETC
Download thousands of free, quality, high resolution stock icons and clipart.
http://icons.mysitemyway.com

Backgrounds ETC
Download thousands of free, quality, high resolution stock website backgrounds, twitter backgrounds, wallpapers and more!
http://backgrounds.mysitemyway.com

Tutorials ETC
Get the PSDs for all our icons and backgrounds, and learn how to make them yourself!
http://tutorials.mysitemyway.com

Web Treats ETC
Our official resource blog!
http://webtreats.mysitemyway.com

Enjoy,
Mysitemyway Design Team
etc@mysitemyway.com